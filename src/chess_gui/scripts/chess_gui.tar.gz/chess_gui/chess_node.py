#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 17-12-6 下午3:44
# @Author  : yu
# @File    : python main.py
# @Desc    :
import sys
import pickle
from tkMessageBox import *
from ttk import *

import opencv.axis as ax
import opencv.chess_look as cl
import opencv.chess_move as cm
import opencv.chess_util as cu
from chess.chess import Chess
from chess_ui import *
from opencv.convenience import *
from opencv.input_dialog import InputDialog
from utils.my_dialog import MyDialog
from utils.xml_parse import xml_parse as xml_p

import threading

import rospy
import actionlib
import chess_msgs.msg
from std_msgs.msg import String
from sensor_msgs.msg import Image as Msg_Image
from cv_bridge import CvBridge, CvBridgeError
import time

COMMAND_RUN = False


price = {
   'R1': None,
   'R2': None,
   'N1': None,
   'N2': None,
   'B1': None,
   'B2': None,
   'A1': None,
   'A2': None,
   'K1': None,
   'C1': None,
   'C2': None,
   'P1': None,
   'P2': None,
   'P3': None,
   'P4': None,
   'P5': None,
   'r1': None,
   'r2': None,
   'n1': None,
   'n2': None,
   'b1': None,
   'b2': None,
   'a1': None,
   'a2': None,
   'k1': None,
   'c1': None,
   'c2': None,
   'p1': None,
   'p2': None,
   'p3': None,
   'p4': None,
   'p5': None,
}

class chess_node(Frame):
    def __init__(self, master=None):
        Frame.__init__(self, master)
        
        reload(sys)
        sys.setdefaultencoding('utf-8')

        self.master.title('中国象棋')
        self.master.config(bg='white')
       
        w, h = self.master.maxsize()
       
        self.master.geometry('{}x{}'.format(w, h))
        menu_bar = Menu(self.master)

        move_menu = Menu(menu_bar, tearoff=1)

        menu_bar.add_command(label="定标1", command=self.mark_1)
        menu_bar.add_command(label="定标2", command=self.mark_2)
        menu_bar.add_command(label="定标3", command=self.mark_3)

        move_menu.add_command(label='开始', command=self.start_move_thread)
        move_menu.add_command(label='停止', command=self.stop_move_thread)
        menu_bar.add_cascade(label='摆棋', menu=move_menu)

        voice_menu = Menu(menu_bar, tearoff=1)
        voice_menu.add_command(label='开启', command=self.start_voice)
        voice_menu.add_command(label='关闭', command=self.stop_voice)
        menu_bar.add_cascade(label='语音', menu=voice_menu)

        self.master['menu'] = menu_bar
        
        self.server = None
       
        self.img_borad = None
        
        self.img_stone = None
        
        self.frame = None
        
        self.video_panel = None
       
        self.canvas = None
       
        # get param
        self.img_path = rospy.get_param('~path')
        self.robot_id = rospy.get_param('~robot_id')
        self.robot_name = rospy.get_param('~robot_name')
        self.chess_action_name = rospy.get_param('~chess_action_name')
        self.ai_ip = rospy.get_param('~ai_ip')
        self.ai_port = rospy.get_param('~ai_port')

        self.createWidgets()
        self.master.wm_protocol("WM_DELETE_WINDOW", self.onClose)
        
        self.bridge = CvBridge()
       
        self.subscriber = rospy.Subscriber("/usb_cam_node/image_rect_color",
                                           Msg_Image, self.img_callback)
        
        self.action_client = actionlib.SimpleActionClient(self.chess_action_name, chess_msgs.msg.StepAction)
       
        self.pub_voice = rospy.Publisher('speech_command', String, queue_size=1)
        self.send_voice_msg('start')
        
        self.sub_voice = rospy.Subscriber("speech_recognize", String, self.speech_callback)

       
       
        self.move_chess = False
        self.chess_move_thread = threading.Thread(target=self.start_move)
        self.stop_chess_move_Event = threading.Event()

    '语音控制'
    def speech_callback(self, data):
       
        global COMMAND_RUN
      
        if COMMAND_RUN:
            return
        id = xml_p(data.data)
        if id == 1:
            COMMAND_RUN = True
            self.stop_voice()
            self.start_play()
            self.start_voice()
            COMMAND_RUN = False
        elif id == 11:
            COMMAND_RUN = True
            self.stop_voice()
            if self.people_go():
                self.robot_go()
            self.start_voice()
            COMMAND_RUN = False
        elif id == 12:
            COMMAND_RUN = True
            self.stop_voice()
            self.start_move_thread()
        elif id == 13:
            COMMAND_RUN = True
            self.stop_voice()
            self.stop_move_thread()
            self.start_voice()
            COMMAND_RUN = False
  
    def start_voice(self):
       
        self.send_voice_msg('on', 1)
    
    def stop_voice(self):
      
        self.send_voice_msg('off', 1)

   
    def img_callback(self, ros_data):
        try:
            self.frame = self.bridge.imgmsg_to_cv2(ros_data, "bgr8")
        except CvBridgeError as e:
            print(e)
        self.video_loop()

   
    def video_loop(self):
        try:
                image = resize(self.frame, width=650)
                image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                image = Image.fromarray(image)
                image = ImageTk.PhotoImage(image)
                if self.video_panel is None:
                    self.video_panel = Label(self.master, image=image, relief="solid", borderwidth=3)
                    self.video_panel.image = image
                    self.video_panel.pack(side=LEFT, padx=10)
                else:
                    self.video_panel.configure(image=image)
                    self.video_panel.image = image
        except RuntimeError, e:
            print("[INFO] caught a RuntimeError")

   
    def mark_1(self):
        img_ori = self.frame
        if img_ori is None:
            showwarning(title=None, message='请先开启摄像头!')
            return
        try:
            self.img_borad = cl.markBoard(img_ori.copy())
            self.img_borad = resize(self.img_borad, 600)
            MyDialog(self, '标定结果', 'board', img_ori)
        except Exception, e:
            showwarning(title=None, message='图片中的棋盘不能横置，不要放置任何棋子!')
            print e
   
    def mark_2(self):
        img_ori = self.frame
        if img_ori is None:
            showwarning(title=None, message='请先开启摄像头!')
            return
        if self.img_borad is not None:
                self.img_stone = cl.markStone(img_ori, 20)
                self.img_stone = resize(self.img_stone, 600)
                MyDialog(self, '标定结果', 'stone', img_ori)
        else:
            showwarning(title=None, message='请先进行棋盘标定步骤1')
   
    def mark_3(self):
        self.check_mark()
        InputDialog(self, '录入坐标')

   
    def start_move_thread(self):
        if not self.check_action_connection:
            self.show_tip('与 ' + self.chess_action_name + ' 失去连接,请重启程序')
            return
        self.check_mark()
        self.send_voice_msg(self.robot_name + '收到2秒之后开始摆棋,请小心！')
       
        self.res_lookStone = cl.lookStone(self.frame)
        
        try:
           self.chess_move_thread.start()
        except Exception, e:
            print 'e'
        self.move_chess = True

    
    def stop_move_thread(self):
        self.move_chess = False
        self.send_voice_msg(self.robot_name + '收到停止摆棋,移动到等待位置')
       
        goal = chess_msgs.msg.StepGoal()
        self.generate_msg(goal,(0,0), (0,0), 2)
        self.send_msg(goal)
        goal.ops = []
        self.start_voice()
        global COMMAND_RUN
        COMMAND_RUN = False

   
    def start_move(self):
        goal = chess_msgs.msg.StepGoal()
        try:
            while not self.stop_chess_move_Event.is_set():
              
                while True:
                    if not self.move_chess:
                        break
                    rl, rn, bl, bn = self.res_lookStone
                    res = cm.moveStone(rl, rn, bl, bn)
                    rospy.logwarn(res)
                    if res is None:
                       
                        self.send_voice_msg(self.robot_name + '摆棋完成 移动到等待位置')
                        self.generate_msg(goal, (0,0), (0,0), 2)
                        self.send_msg(goal)
                        goal.ops = []
                        self.start_voice()
                        global COMMAND_RUN
                        COMMAND_RUN = False
                        self.move_chess = False
                        break
                    
                    if res[1]:
                        self.send_voice_msg('移动红方'+cl.get_chess_name(rn[res[0]]))
                    else:
                        if cl.get_chess_name(bn[res[0]]) == '帅':
                            name = '将'
                        elif cl.get_chess_name(bn[res[0]]) == '兵':
                            name = '卒'
                        else:
                            name = cl.get_chess_name(bn[res[0]])
                        self.send_voice_msg('移动黑方' + name)
                    # =============================
                    img_1 = cl.mergeStone(rl, bl, rn, bn)
                    cv2.line(img_1, res[2], res[3], 255, 1)
                    img_1 = resize(img_1, width=800)
                    cv2.imshow('move_step,', img_1)
                    # =============================
                    self.generate_msg(goal, res[2], res[3], 0)
                    if cv2.waitKey(1000) & 0xFF == ord('q'):
                        break
                    if self.send_msg(goal):
                        goal.ops = []
                        continue
                    else:
                        self.stop_move_thread()
                        break
                cv2.destroyAllWindows()
        except Exception, e:
            rospy.logwarn(e)
            rospy.logwarn('摆棋出现错误')

   
    def generate_msg(self, goal, pick, place, type):
        op = chess_msgs.msg.Operation()
        op.type = type
        op.pick_x, op.pick_y = ax.axis(pick)
        op.place_x, op.place_y = ax.axis(place)
        if self.robot_id == 'ur':
            op.pick_y, op.pick_x = ax.axis(pick)
            op.place_y, op.place_x = ax.axis(place)
        # far = 0; near = 1
        if cl.xy2Grid(pick)[1] > 4:
            op.pick_type = 1
        else:
            op.pick_type = 0

        if cl.xy2Grid(place)[1] > 4:
            op.place_type = 1
        else:
            op.place_type = 0
        goal.ops.append(op)
        # Sends the goal to the action server.
        rospy.logwarn('----------------')
        rospy.logwarn(pick)
        rospy.logwarn(place)
        rospy.logwarn(goal)
        rospy.logwarn('----------------')
        return goal

   
    def send_msg(self, goal):
        self.action_client.send_goal(goal)
       
        result = self.action_client.wait_for_result(rospy.Duration(60, 0))
        if result:
            result_data = self.action_client.get_result()
            if result_data.res:
                self.show_tip('移动成功')
            else:
                self.show_tip('移动失败')
            return True
        else:
            if not self.check_action_connection:
                self.show_tip('与 ' + self.chess_action_name + ' 失去连接,请重启')
                return False
            else:
                self.show_tip('移动棋子超时')
                return True

   
    def check_action_connection(self):
        return self.action_client.wait_for_server(rospy.Duration(1, 0))

   
    def update_price(self):
        update_price_coordinates(self.canvas, price)

  
    def start_play(self):
        self.check_mark()
        rl, rn, bl, bn = cl.lookStone(self.frame)
        board, red_up = cl.stone2Board(rl, rn, bl, bn)
        board = self.strBoard(board)
       
        if self.server is None:
            self.server = Chess(self.ai_ip, self.ai_port)
        res = self.server.startBoard(
            board, not red_up)
        if not (res is None):
            s = u'初始化错误：' + res
            self.show_tip(s)
        else:
           
            self.structure_price_coordinates(rl, rn, bl, bn)
            self.send_voice_msg('初始化完毕,可以开始下棋了')

    def merge_move(self):
        if self.people_go():
                self.robot_go()
    def robot_go(self):
        if self.server is None:
            self.show_tip('请先点击开始下棋或者发送开始下棋命令！')
            return
        self.send_voice_msg('轮到' + self.robot_name + '下棋了请您离' + self.robot_name + '远一点！')
       
        rl, rn, bl, bn = cl.lookStone(self.frame)
        res = self.server.thinkAndMove(False)
       
        goal = chess_msgs.msg.StepGoal()
        if res:
            pick, place = self.coordinate_trans(res[2:])
            has = cl.hasStone(rl, rn, bl, bn, place)
            if has is None:
               
                move_price(self.canvas, pick, place)
               
                place = cl.grid2XY(place)
                h1, h2, h3 = cl.hasStone(rl, rn, bl, bn, pick)
                self.send_voice_msg('走'+cl.get_chess_name(h2,h3))
                goal = self.generate_msg(goal, h1[0], place, 0)
                self.send_msg(goal)
                goal.ops = []
               
                self.send_voice_msg('移动' + self.robot_name + '到等待位置')
                self.generate_msg(goal, pick, place, 2)
                self.send_msg(goal)
            else:
               
                capture_price(self.canvas, place)
                move_price(self.canvas, pick, place)
               
                h1,h2,h3 = cl.hasStone(rl, rn, bl, bn, place)
                self.send_voice_msg('吃' + cl.get_chess_name(h2,h3))
                goal = self.generate_msg(goal, h1[0], pick, 1)
                self.send_msg(goal)
                goal.ops = []

               
                h1, h2, h3 = cl.hasStone(rl, rn, bl, bn, pick)
                self.send_voice_msg('走' + cl.get_chess_name(h2,h3))
                place = cl.grid2XY(place)
                goal = self.generate_msg(goal, h1[0], place, 0)
                self.send_msg(goal)
               
                self.send_voice_msg('移动' + self.robot_name + '到等待位置')
                goal.ops = []
                self.generate_msg(goal, pick, place, 2)
                self.send_msg(goal)
        else:
            self.send_voice_msg('这已经没什么可走的了！')
   
    def people_go(self):
        if self.server is None:
            self.show_tip('请先点击开始下棋,或者发送开始下棋命令！')
            return
       
        rl, rn, bl, bn = cl.lookStone(self.frame)
        self.structure_price_coordinates(rl, rn, bl, bn)
        board, red_up = cl.stone2Board(rl, rn, bl, bn)
        board = self.strBoard(board)
        result = self.server.setBoard(board)
        if len(result) == 0:
            self.show_tip('您还没有走棋呢！')
            return False
        elif result[:2] == '0:':
            return True
        else:
            result= result.replace('傌','馬')
            result= result.replace('車','居')
            result= result.replace('俥','居')
            self.show_tip(result)
            return False
    
    def check_mark(self):
        if self.frame is None:
            showwarning(title=None, message="请先开启摄像头！")
            return
        if self.img_borad is None:
            img_borad = cv2.imread(self.img_path + self.robot_id + '_' + 'board.png', cv2.IMREAD_COLOR)
            if img_borad is not None:
                self.img_borad = cl.markBoard(img_borad.copy())
            else:
                showwarning(title=None, message="请先进行标定步骤一！")
                return

        if self.img_stone is None:
            img_stone = cv2.imread(self.img_path + self.robot_id + '_' + 'stone.png', cv2.IMREAD_COLOR)
            if img_stone is not None:
                self.img_stone = cl.markStone(img_stone.copy(),20)
            else:
                showwarning(title=None, message="请先进行标定步骤二！")
                return
        data = None
        try:
            pkl_file = open(self.img_path + self.robot_id + '_' + 'mark.txt', 'rb')
            data = pickle.load(pkl_file)
            pkl_file.close()
        except Exception, e:
            print e
        if data is None:
            #showwarning(title=None, message="请先进行标定步骤三！")
            return

    def createWidgets(self):
       
        self.canvas = draw_chess(self.master)
        button_panel = Frame(self.master, width=40, height=800,bg='white')
        Button(button_panel, text='开始下棋', command=self.start_play).pack(pady=10)
        Button(button_panel, text=self.robot_name + '下棋', command=self.merge_move).pack(pady=10)
        # Button(button_panel, text='我已完成', command=self.people_go).pack(pady=10)
        button_panel.pack(side=LEFT, padx=10)

   
    def strBoard(self, board):
        one = ''
        two = ''
        for x in xrange(len(board)):
            if x < cu.Rows / 2:
                one = one + ''.join(board[x]) + '/ '
            else:
                two = two + ''.join(board[x]) + '/ '
        return (one + two).replace(' ', '')

    def structure_price_coordinates(self, rl, rn, bl, bn):
        price_coordinates=price
        p=0
        c=0
        r=0
        n=0
        b=0
        a=0
        for i,v in enumerate(rl):
            key = str(rn[i]).upper()
            if key == 'K':
                price_coordinates['K1'] = cl.xy2Grid(v[0])
            elif key == 'P':
                price_coordinates[key+str(p+1)] = cl.xy2Grid(v[0])
                p = p+1
            elif key == 'C':
                price_coordinates[key + str(c+1)] = cl.xy2Grid(v[0])
                c = c + 1
            elif key == 'R':
                price_coordinates[key + str(r + 1)] = cl.xy2Grid(v[0])
                r = r + 1
            elif key == 'N':
                price_coordinates[key + str(n + 1)] = cl.xy2Grid(v[0])
                n = n + 1
            elif key == 'B':
                price_coordinates[key + str(b + 1)] = cl.xy2Grid(v[0])
                b = b + 1
            elif key == 'A':
                price_coordinates[key + str(a + 1)] = cl.xy2Grid(v[0])
                a = a + 1

        p = 0
        c = 0
        r = 0
        n = 0
        b = 0
        a = 0
        for i, v in enumerate(bl):
            key = str(bn[i])
            if key == 'k':
                price_coordinates['k1'] = cl.xy2Grid(v[0])
            elif key == 'p':
                price_coordinates[key + str(p + 1)] = cl.xy2Grid(v[0])
                p = p + 1
            elif key == 'c':
                price_coordinates[key + str(c + 1)] = cl.xy2Grid(v[0])
                c = c + 1
            elif key == 'r':
                price_coordinates[key + str(r + 1)] = cl.xy2Grid(v[0])
                r = r + 1
            elif key == 'n':
                price_coordinates[key + str(n + 1)] = cl.xy2Grid(v[0])
                n = n + 1
            elif key == 'b':
                price_coordinates[key + str(b + 1)] = cl.xy2Grid(v[0])
                b = b + 1
            elif key == 'a':
                price_coordinates[key + str(a + 1)] = cl.xy2Grid(v[0])
                a = a + 1
        update_price_coordinates(self.canvas,price_coordinates)
   
    def coordinate_trans(self, move):
        if move and len(move) != 4:
            print '移动出错'
        a1 = (self.to_letter(move[0]), 9-int(move[1]))
        a2 = (self.to_letter(move[2]), 9 - int(move[3]))
        return a1, a2

    def to_letter(self, s):
        if s == 'a':
            s = 0
        elif s == 'b':
            s = 1
        elif s == 'c':
            s = 2
        elif s == 'd':
            s = 3
        elif s == 'e':
            s = 4
        elif s == 'f':
            s = 5
        elif s == 'g':
            s = 6
        elif s == 'h':
            s = 7
        elif s == 'i':
            s = 8
        return s

    def send_voice_msg(self, message, flag=0):
        if flag == 0:
            msg = "talk " + message
        elif flag == 1:
            msg = "listen " + message
        if not rospy.is_shutdown():
            self.pub_voice.publish(msg)

   
    def show_tip(self, message):
        self.send_voice_msg(message)
       

    
    def onClose(self):
        print("[INFO] closing...")
        try:
            self.bridge = None
            self.server = None
            self.canvas = None
            self.action_client = None
            self.pub_voice = None
            self.subscriber = None
            self.stop_chess_move_Event.set()
        except Exception,e:
            rospy.logwarn('closing')
        # Shutdown
        rospy.signal_shutdown("Done.")
        self.master.quit()

if __name__ == "__main__":
    try:
       
        rospy.init_node('chess_node')
        app = chess_node()
        app.mainloop()
    except rospy.ROSInterruptException:
        print "program interrupted before completion"
